﻿using System;
using System.Runtime.Serialization;

namespace Trading.Lib.Redis.Exceptions
{
    [Serializable]
    public class NotExistDataException : Exception
    {
        public NotExistDataException() : base()
        {
        }
        protected NotExistDataException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        public NotExistDataException(string message) : base(message)
        {
        }

        public NotExistDataException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
