﻿using StackExchange.Redis;
using System;
using System.Threading.Tasks;

namespace Trading.Lib.Redis
{
    public interface IRedisHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<ConnectionMultiplexer> PersistentConnection();
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        /// <exception cref="NotExistDataException"></exception>
        public Task<T> GetObject<T>(string key, bool throwNotExist = false);
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="expiry"></param>
        /// <returns></returns>
        public Task<bool> SetObject<T>(string key, T value, TimeSpan? expiry = null);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public Task<bool> Clear(string key);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        /// <exception cref="NotExistDataException"></exception>
        public Task<string> GetString(string key, bool throwNotExist = false);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="expiry"></param>
        /// <returns></returns>
        public Task<bool> SetString(string key, string value, TimeSpan? expiry = null);
    }
}
