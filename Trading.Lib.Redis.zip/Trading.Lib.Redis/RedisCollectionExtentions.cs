﻿using Microsoft.Extensions.DependencyInjection;
using System;

namespace Trading.Lib.Redis
{
    public static class RedisCollectionExtentions
    {
        public static void AddRedisHelper(this IServiceCollection services, Action<RedisConfigOption> setupAction)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            if (setupAction == null)
            {
                throw new ArgumentNullException(nameof(setupAction));
            }
            services.AddOptions();
            services.Configure(setupAction);
            services.AddSingleton<IRedisHelper, RedisHelper>();
        }
    }
}
