﻿namespace Trading.Lib.Redis
{
    public class RedisConfigOption
    {
        public string ConnectionString { get; set; }
        public int DatabaseNumber { get; set; } = -1;
        public int? MinThreadPool { get; set; }
        public string Prefix { get; set; }
    }
}
