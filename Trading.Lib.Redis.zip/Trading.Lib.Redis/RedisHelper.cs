﻿using Microsoft.Extensions.Options;
using StackExchange.Redis;
using System;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Trading.Lib.Redis.Exceptions;

namespace Trading.Lib.Redis
{
    public class RedisHelper : IRedisHelper
    {
        private ConnectionMultiplexer _connection;
        private readonly RedisConfigOption _redisConfigOption;
        public RedisHelper(IOptions<RedisConfigOption> configAction)
        {
            _redisConfigOption = configAction.Value;
        }

        public async Task<ConnectionMultiplexer> PersistentConnection()
        {
            if (_connection == null || !_connection.IsConnected)
            {
                _connection = await ConnectionMultiplexer.ConnectAsync(_redisConfigOption.ConnectionString);
            }
            return _connection;
        }

        private RedisKey GetKey(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentNullException(nameof(key));
            }
            return new RedisKey($"{_redisConfigOption.Prefix}_{key}");
        }

        public async Task<T> GetObject<T>(string key, bool throwNotExist = false)
        {
            var db = (await PersistentConnection()).GetDatabase(_redisConfigOption.DatabaseNumber);
            var result = await db.StringGetAsync(GetKey(key));
            if (result.IsNullOrEmpty)
            {
                if (throwNotExist)
                    throw new NotExistDataException($"Key {key} not found");
                else
                    return default;
            }
            return JsonSerializer.Deserialize<T>(result);
        }

        public async Task<bool> SetObject<T>(string key, T value, TimeSpan? expiry = null)
        {
            var db = (await PersistentConnection()).GetDatabase(_redisConfigOption.DatabaseNumber);
            RedisValue redisValue = new(JsonSerializer.Serialize(value));
            return await db.StringSetAsync(GetKey(key), redisValue, expiry);
        }

        public async Task<bool> Clear(string key)
        {
            var db = (await PersistentConnection()).GetDatabase(_redisConfigOption.DatabaseNumber);
            return await db.KeyDeleteAsync(GetKey(key));
        }

        public async Task<string> GetString(string key, bool throwNotExist = false)
        {
            var db = (await PersistentConnection()).GetDatabase(_redisConfigOption.DatabaseNumber);
            var result = await db.StringGetAsync(GetKey(key));
            if (result.IsNullOrEmpty && throwNotExist)
                throw new NotExistDataException($"Key {key} not found");
            return result;
        }

        public async Task<bool> SetString(string key, string value, TimeSpan? expiry = null)
        {
            var db = (await PersistentConnection()).GetDatabase(_redisConfigOption.DatabaseNumber);
            RedisValue redisValue = new(value);
            return await db.StringSetAsync(GetKey(key), redisValue, expiry);
        }
    }
}
